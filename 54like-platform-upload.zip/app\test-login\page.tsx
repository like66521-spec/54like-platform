"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export default function TestLoginPage() {
  const router = useRouter()

  useEffect(() => {
    // 模拟登录成功，3秒后跳转到首页
    const timer = setTimeout(() => {
      router.push("/?login=success&user=测试用户&provider=wechat")
    }, 3000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="min-h-screen bg-[#f5f5f5] flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-lg text-center">
        <h1 className="text-2xl font-bold text-[#333333] mb-4">测试登录</h1>
        <p className="text-[#666666] mb-4">正在模拟微信登录...</p>
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#4caf50] mx-auto"></div>
        <p className="text-sm text-[#999999] mt-4">3秒后跳转到首页</p>
      </div>
    </div>
  )
}
