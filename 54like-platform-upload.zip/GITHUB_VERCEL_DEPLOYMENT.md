# GitHub + Vercel 部署指南

## 🚀 最简单的部署方案

使用GitHub + Vercel的组合，无需VPS，自动部署，完全免费！

## 📋 部署步骤

### 1. 准备GitHub仓库

1. 在GitHub上创建一个新仓库
2. 将代码推送到GitHub：
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/你的用户名/你的仓库名.git
git push -u origin main
```

### 2. 设置Vercel

1. 访问 [vercel.com](https://vercel.com)
2. 使用GitHub账号登录
3. 点击 "New Project"
4. 选择你的GitHub仓库
5. 点击 "Deploy"

### 3. 配置环境变量

在Vercel项目设置中添加以下环境变量：

#### 必需的环境变量：
```
DATABASE_URL=mysql://用户名:密码@主机:端口/数据库名
NEXTAUTH_SECRET=你的随机密钥
NEXTAUTH_URL=https://你的域名.vercel.app
```

#### 可选的环境变量：
```
NEXTAUTH_GITHUB_ID=GitHub OAuth ID
NEXTAUTH_GITHUB_SECRET=GitHub OAuth Secret
```

### 4. 设置数据库

#### 选项A：使用PlanetScale（推荐）
1. 访问 [planetscale.com](https://planetscale.com)
2. 创建免费账户
3. 创建新数据库
4. 复制连接字符串到Vercel环境变量

#### 选项B：使用Railway
1. 访问 [railway.app](https://railway.app)
2. 创建免费账户
3. 添加MySQL服务
4. 复制连接字符串到Vercel环境变量

#### 选项C：使用Supabase
1. 访问 [supabase.com](https://supabase.com)
2. 创建免费项目
3. 在SQL编辑器中运行数据库迁移
4. 复制连接字符串到Vercel环境变量

### 5. 自动部署

一旦设置完成，每次推送到GitHub主分支都会自动部署到Vercel！

## 🔧 本地开发

```bash
# 安装依赖
npm install

# 设置环境变量
cp .env.example .env.local

# 运行数据库迁移
npx prisma db push

# 启动开发服务器
npm run dev
```

## 📱 访问应用

部署完成后，你的应用将在以下地址可用：
- 生产环境：`https://你的项目名.vercel.app`
- 预览环境：每次PR都会生成预览链接

## 🎯 优势

✅ **完全免费** - GitHub和Vercel都有免费额度
✅ **自动部署** - 推送代码即自动部署
✅ **全球CDN** - Vercel提供全球加速
✅ **HTTPS证书** - 自动SSL证书
✅ **预览环境** - 每个PR都有预览链接
✅ **零维护** - 无需管理服务器

## 🆘 常见问题

### Q: 数据库连接失败？
A: 检查DATABASE_URL格式，确保数据库服务正常运行

### Q: 构建失败？
A: 检查环境变量是否完整，查看Vercel构建日志

### Q: 如何更新应用？
A: 直接推送代码到GitHub，Vercel会自动重新部署

## 📞 技术支持

如果遇到问题，可以：
1. 查看Vercel部署日志
2. 检查GitHub Actions状态
3. 确认环境变量配置

---

**🎉 恭喜！你的应用现在已经部署到云端了！**

