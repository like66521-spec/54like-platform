import { NextRequest, NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { generateWechatSign } from "@/lib/wechat-utils"

// 微信支付回调处理
export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    console.log("微信支付回调数据:", body)

    // 解析XML数据
    const paymentData = parseXML(body)
    
    // 验证签名
    const isValidSign = verifyWechatSign(paymentData)
    if (!isValidSign) {
      console.error("微信支付回调签名验证失败")
      return new NextResponse("<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[签名验证失败]]></return_msg></xml>", {
        status: 400,
        headers: { "Content-Type": "application/xml" }
      })
    }

    // 检查支付结果
    if (paymentData.return_code === "SUCCESS" && paymentData.result_code === "SUCCESS") {
      const outTradeNo = paymentData.out_trade_no
      const transactionId = paymentData.transaction_id
      const totalFee = parseInt(paymentData.total_fee) / 100 // 转换为元

      // 查找支付记录
      const payment = await prisma.payment.findFirst({
        where: {
          transactionId: outTradeNo,
          status: "PENDING"
        },
        include: {
          article: true,
          user: true
        }
      })

      if (payment) {
        // 验证金额
        if (payment.amount !== totalFee) {
          console.error("支付金额不匹配:", payment.amount, totalFee)
          return new NextResponse("<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[金额不匹配]]></return_msg></xml>", {
            status: 400,
            headers: { "Content-Type": "application/xml" }
          })
        }

        // 更新支付状态
        await prisma.payment.update({
          where: { id: payment.id },
          data: {
            status: "COMPLETED",
            transactionId: transactionId,
            updatedAt: new Date()
          }
        })

        console.log(`支付成功: 用户${payment.user.name}购买文章${payment.article.title}`)

        // 返回成功响应
        return new NextResponse("<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>", {
          status: 200,
          headers: { "Content-Type": "application/xml" }
        })
      } else {
        console.error("未找到支付记录:", outTradeNo)
        return new NextResponse("<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[订单不存在]]></return_msg></xml>", {
          status: 400,
          headers: { "Content-Type": "application/xml" }
        })
      }
    } else {
      console.error("微信支付失败:", paymentData.return_msg, paymentData.err_code_des)
      return new NextResponse("<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[支付失败]]></return_msg></xml>", {
        status: 400,
        headers: { "Content-Type": "application/xml" }
      })
    }

  } catch (error) {
    console.error("微信支付回调处理错误:", error)
    return new NextResponse("<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[系统错误]]></return_msg></xml>", {
      status: 500,
      headers: { "Content-Type": "application/xml" }
    })
  }
}

// 解析XML
function parseXML(xml: string): any {
  const result: any = {}
  const regex = /<(\w+)><!\[CDATA\[(.*?)\]\]><\/\1>/g
  let match
  
  while ((match = regex.exec(xml)) !== null) {
    result[match[1]] = match[2]
  }
  
  return result
}

// 验证微信支付签名
function verifyWechatSign(data: any): boolean {
  const apiKey = process.env.WECHAT_API_KEY || "your_api_key"
  
  // 1. 参数名ASCII码从小到大排序
  const sortedKeys = Object.keys(data).filter(key => key !== "sign").sort()
  
  // 2. 拼接参数
  let stringA = ""
  sortedKeys.forEach(key => {
    if (data[key] && data[key] !== "") {
      stringA += `${key}=${data[key]}&`
    }
  })
  
  // 3. 拼接API密钥
  stringA += `key=${apiKey}`
  
  // 4. MD5加密并转大写
  const crypto = require("crypto")
  const sign = crypto.createHash("md5").update(stringA).digest("hex").toUpperCase()
  
  return sign === data.sign
}





