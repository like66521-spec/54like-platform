import { NextRequest, NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { auth } from "@/lib/auth"
import { applyRateLimit } from "@/lib/rate-limit"
import { sanitizeText, validateStringLength } from "@/lib/validation"

// 获取文章评论列表
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const articleId = searchParams.get("articleId")
    const page = parseInt(searchParams.get("page") || "1")
    const limit = parseInt(searchParams.get("limit") || "10")

    if (!articleId) {
      return NextResponse.json({ error: "缺少文章ID" }, { status: 400 })
    }

    // 验证文章是否存在
    const article = await prisma.article.findUnique({
      where: { id: articleId }
    })

    if (!article) {
      return NextResponse.json({ error: "文章不存在" }, { status: 404 })
    }

    // 获取评论列表（只获取顶级评论，回复通过parentId关联）
    const comments = await prisma.comment.findMany({
      where: {
        articleId,
        parentId: null // 只获取顶级评论
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        replies: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          },
          orderBy: { createdAt: "asc" }
        },
        _count: {
          select: { likesRelation: true }
        }
      },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * limit,
      take: limit
    })

    // 获取评论总数
    const total = await prisma.comment.count({
      where: {
        articleId,
        parentId: null
      }
    })

    return NextResponse.json({
      comments: comments.map(comment => ({
        ...comment,
        likes: comment._count.likesRelation
      })),
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    })
  } catch (error) {
    console.error("获取评论列表错误:", error)
    return NextResponse.json({ error: "获取评论失败" }, { status: 500 })
  }
}

// 创建评论
export async function POST(request: NextRequest) {
  try {
    // 应用速率限制
    const rateLimitResponse = applyRateLimit(request, { windowMs: 60 * 1000, maxRequests: 10 })
    if (rateLimitResponse) {
      return rateLimitResponse
    }

    // 验证用户登录
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const body = await request.json()
    const { articleId, content, parentId } = body

    // 验证输入
    if (!articleId || !content) {
      return NextResponse.json({ error: "缺少必要字段" }, { status: 400 })
    }

    if (!validateStringLength(content, 1, 1000)) {
      return NextResponse.json({ error: "评论内容长度必须在1-1000字符之间" }, { status: 400 })
    }

    // 清理输入内容
    const sanitizedContent = sanitizeText(content)

    // 验证文章是否存在
    const article = await prisma.article.findUnique({
      where: { id: articleId }
    })

    if (!article) {
      return NextResponse.json({ error: "文章不存在" }, { status: 404 })
    }

    // 如果是回复评论，验证父评论是否存在
    if (parentId) {
      const parentComment = await prisma.comment.findUnique({
        where: { id: parentId }
      })

      if (!parentComment) {
        return NextResponse.json({ error: "父评论不存在" }, { status: 404 })
      }

      // 确保父评论属于同一文章
      if (parentComment.articleId !== articleId) {
        return NextResponse.json({ error: "评论文章不匹配" }, { status: 400 })
      }
    }

    // 创建评论
    const comment = await prisma.comment.create({
      data: {
        content: sanitizedContent,
        articleId,
        userId: session.user.id,
        parentId: parentId || null
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    })

    return NextResponse.json({ comment })
  } catch (error) {
    console.error("创建评论错误:", error)
    return NextResponse.json({ error: "创建评论失败" }, { status: 500 })
  }
}

// 删除评论
export async function DELETE(request: NextRequest) {
  try {
    // 验证用户登录
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const commentId = searchParams.get("id")

    if (!commentId) {
      return NextResponse.json({ error: "缺少评论ID" }, { status: 400 })
    }

    // 查找评论
    const comment = await prisma.comment.findUnique({
      where: { id: commentId },
      include: { user: true }
    })

    if (!comment) {
      return NextResponse.json({ error: "评论不存在" }, { status: 404 })
    }

    // 检查权限：只有评论作者或管理员可以删除
    const isAuthor = comment.userId === session.user.id
    const isAdmin = session.user.role === "ADMIN" || session.user.role === "SUPER_ADMIN"

    if (!isAuthor && !isAdmin) {
      return NextResponse.json({ error: "无权删除此评论" }, { status: 403 })
    }

    // 删除评论（级联删除回复）
    await prisma.comment.delete({
      where: { id: commentId }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("删除评论错误:", error)
    return NextResponse.json({ error: "删除评论失败" }, { status: 500 })
  }
}
