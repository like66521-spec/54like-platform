import { NextRequest, NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { auth } from "@/lib/auth"
import { applyRateLimit } from "@/lib/rate-limit"

// 创建Prisma客户端实例（兼容Edge Runtime）
const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL || 'file:./prisma/dev.db'
    }
  }
})

// 点赞/取消点赞评论
export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // 应用速率限制
    const rateLimitResponse = applyRateLimit(request, { windowMs: 60 * 1000, maxRequests: 20 })
    if (rateLimitResponse) {
      return rateLimitResponse
    }

    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const commentId = params.id

    // 检查评论是否存在
    const comment = await prisma.comment.findUnique({
      where: { id: commentId }
    })

    if (!comment) {
      return NextResponse.json({ error: "评论不存在" }, { status: 404 })
    }

    // 检查是否已经点赞
    const existingLike = await prisma.commentLike.findUnique({
      where: {
        userId_commentId: {
          userId: session.user.id,
          commentId: commentId
        }
      }
    })

    if (existingLike) {
      // 取消点赞
      await prisma.commentLike.delete({
        where: {
          userId_commentId: {
            userId: session.user.id,
            commentId: commentId
          }
        }
      })

      // 更新评论点赞数
      await prisma.comment.update({
        where: { id: commentId },
        data: { likes: { decrement: 1 } }
      })

      const updatedComment = await prisma.comment.findUnique({
        where: { id: commentId },
        select: { likes: true }
      })

      return NextResponse.json({ 
        success: true, 
        action: "unliked",
        newLikes: updatedComment?.likes || 0,
        message: "取消点赞成功" 
      })
    } else {
      // 添加点赞
      await prisma.commentLike.create({
        data: {
          userId: session.user.id,
          commentId: commentId
        }
      })

      // 更新评论点赞数
      await prisma.comment.update({
        where: { id: commentId },
        data: { likes: { increment: 1 } }
      })

      const updatedComment = await prisma.comment.findUnique({
        where: { id: commentId },
        select: { likes: true }
      })

      return NextResponse.json({ 
        success: true, 
        action: "liked",
        newLikes: updatedComment?.likes || 0,
        message: "点赞成功" 
      })
    }
  } catch (error) {
    console.error("Like comment error:", error)
    return NextResponse.json({ error: "操作失败" }, { status: 500 })
  }
}



