import { notFound } from "next/navigation"
import prisma from "@/lib/prisma"
import { Header } from "@/components/header"
import { SidebarLeft } from "@/components/sidebar-left"
import { SidebarRight } from "@/components/sidebar-right"
import { ArticleCard } from "@/components/article-card"
import { mockCategories, mockArticles } from "@/lib/mock-data"

interface CategoryPageProps {
  params: Promise<{
    slug: string
  }>
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = await params
  
  let category
  let articles = []
  
  try {
    // 尝试从数据库获取数据
    category = await prisma.category.findUnique({
      where: { slug }
    })

    if (category) {
      articles = await prisma.article.findMany({
        where: {
          categoryId: category.id,
          isPublished: true
        },
        include: {
          author: true,
          category: true,
          _count: {
            select: { comments: true }
          }
        },
        orderBy: { publishedAt: "desc" },
        take: 8
      })
    }
  } catch (error) {
    console.log("数据库连接失败，使用模拟数据")
  }

  // 如果数据库连接失败或找不到分类，使用模拟数据
  if (!category) {
    category = mockCategories.find(c => c.slug === slug)
    if (!category) {
      notFound()
    }
    
    // 从模拟数据中筛选该分类的文章
    articles = mockArticles
      .filter(article => article.categoryId === category.id)
      .slice(0, 8)
      .map(article => ({
        ...article,
        _count: { comments: article.comments }
      }))
  }

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <Header />
      
      <div className="flex max-w-[1204px] mx-auto pt-3">
        <SidebarLeft />
        
        <div className="w-0.5"></div>
        
        <main className="w-[700px] flex-shrink-0 pb-8 ml-[18px]">
          <div className="bg-white rounded-lg border border-[#e0e0e0] p-4 mb-3">
            <h1 className="text-2xl font-bold text-[#333333] mb-2">
              {category.name}
            </h1>
            {category.description && (
              <p className="text-[#666666] text-sm">
                {category.description}
              </p>
            )}
          </div>

          <div className="space-y-3">
            {articles.map((article) => (
              <ArticleCard 
                key={article.id} 
                article={{
                  ...article,
                  comments: article._count.comments
                }} 
              />
            ))}
          </div>

          {articles.length === 0 && (
            <div className="bg-white rounded-lg border border-[#e0e0e0] p-8 text-center">
              <p className="text-[#666666]">该分类下暂无文章</p>
            </div>
          )}
        </main>

        <div className="w-6"></div>

        <div className="w-[300px] flex-shrink-0 hidden xl:block">
          <SidebarRight />
        </div>
      </div>
    </div>
  )
}