import { NextRequest, NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { auth } from "@/lib/auth"
import { applyRateLimit } from "@/lib/rate-limit"

// 点赞/取消点赞评论
export async function POST(request: NextRequest) {
  try {
    // 应用速率限制
    const rateLimitResponse = applyRateLimit(request, { windowMs: 60 * 1000, maxRequests: 20 })
    if (rateLimitResponse) {
      return rateLimitResponse
    }

    // 验证用户登录
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const body = await request.json()
    const { commentId } = body

    if (!commentId) {
      return NextResponse.json({ error: "缺少评论ID" }, { status: 400 })
    }

    // 验证评论是否存在
    const comment = await prisma.comment.findUnique({
      where: { id: commentId }
    })

    if (!comment) {
      return NextResponse.json({ error: "评论不存在" }, { status: 404 })
    }

    // 检查是否已经点赞
    const existingLike = await prisma.commentLike.findUnique({
      where: {
        userId_commentId: {
          userId: session.user.id,
          commentId: commentId
        }
      }
    })

    if (existingLike) {
      // 取消点赞
      await prisma.commentLike.delete({
        where: {
          userId_commentId: {
            userId: session.user.id,
            commentId: commentId
          }
        }
      })

      // 更新评论点赞数
      await prisma.comment.update({
        where: { id: commentId },
        data: { likes: { decrement: 1 } }
      })

      return NextResponse.json({ 
        success: true, 
        action: "unliked",
        message: "取消点赞成功" 
      })
    } else {
      // 添加点赞
      await prisma.commentLike.create({
        data: {
          userId: session.user.id,
          commentId: commentId
        }
      })

      // 更新评论点赞数
      await prisma.comment.update({
        where: { id: commentId },
        data: { likes: { increment: 1 } }
      })

      return NextResponse.json({ 
        success: true, 
        action: "liked",
        message: "点赞成功" 
      })
    }
  } catch (error) {
    console.error("评论点赞错误:", error)
    return NextResponse.json({ error: "操作失败" }, { status: 500 })
  }
}

// 获取用户对评论的点赞状态
export async function GET(request: NextRequest) {
  try {
    // 验证用户登录
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const commentId = searchParams.get("commentId")

    if (!commentId) {
      return NextResponse.json({ error: "缺少评论ID" }, { status: 400 })
    }

    // 检查用户是否点赞了该评论
    const like = await prisma.commentLike.findUnique({
      where: {
        userId_commentId: {
          userId: session.user.id,
          commentId: commentId
        }
      }
    })

    return NextResponse.json({ 
      isLiked: !!like 
    })
  } catch (error) {
    console.error("获取点赞状态错误:", error)
    return NextResponse.json({ error: "获取状态失败" }, { status: 500 })
  }
}





