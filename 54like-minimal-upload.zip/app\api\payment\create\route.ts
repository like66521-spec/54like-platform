import { type NextRequest, NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { auth } from "@/lib/auth"
import { applyRateLimit } from "@/lib/rate-limit"
import { sanitizeObject, validateStringLength } from "@/lib/validation"

export async function POST(request: NextRequest) {
  try {
    // 应用严格速率限制
    const rateLimitResponse = applyRateLimit(request, { windowMs: 15 * 60 * 1000, maxRequests: 5 })
    if (rateLimitResponse) {
      return rateLimitResponse
    }

    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const body = await request.json()
    const { articleId, amount, method } = sanitizeObject(body)

    // 验证输入
    if (!articleId || !amount || !method) {
      return NextResponse.json({ error: "缺少必要字段" }, { status: 400 })
    }

    if (method !== "wechat" && method !== "alipay") {
      return NextResponse.json({ error: "不支持的支付方式" }, { status: 400 })
    }

    if (amount <= 0 || amount > 10000) {
      return NextResponse.json({ error: "支付金额无效" }, { status: 400 })
    }

    // 检查文章是否存在且为付费文章
    const article = await prisma.article.findUnique({
      where: { id: articleId }
    })

    if (!article) {
      return NextResponse.json({ error: "文章不存在" }, { status: 404 })
    }

    if (!article.isPaid) {
      return NextResponse.json({ error: "该文章不是付费文章" }, { status: 400 })
    }

    if (article.price !== amount) {
      return NextResponse.json({ error: "支付金额不匹配" }, { status: 400 })
    }

    // 检查是否已经支付过
    const existingPayment = await prisma.payment.findFirst({
      where: {
        articleId,
        userId: session.user.id,
        status: "COMPLETED"
      }
    })

    if (existingPayment) {
      return NextResponse.json({ error: "您已经购买过该文章" }, { status: 400 })
    }

    // 创建支付记录
    const payment = await prisma.payment.create({
      data: {
        articleId,
        userId: session.user.id,
        amount,
        method: method.toUpperCase() as "WECHAT" | "ALIPAY",
        status: "PENDING",
        transactionId: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      }
    })

    // 生成支付二维码URL（模拟）
    const qrCodeUrl = method === "wechat" 
      ? `/wechat-qr-placeholder.jpg?paymentId=${payment.id}`
      : `/alipay-qr-placeholder.jpg?paymentId=${payment.id}`

    return NextResponse.json({
      success: true,
      payment: {
        id: payment.id,
        articleId: payment.articleId,
        amount: payment.amount,
        method: payment.method,
        status: payment.status,
        qrCodeUrl,
        createdAt: payment.createdAt
      }
    })
  } catch (error) {
    console.error("Payment creation error:", error)
    return NextResponse.json({ error: "创建支付失败" }, { status: 500 })
  }
}
