import { NextRequest, NextResponse } from "next/server"
import prisma from "@/lib/prisma"

// 支付宝支付回调处理
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const paymentData: any = {}
    
    // 解析表单数据
    for (const [key, value] of formData.entries()) {
      paymentData[key] = value.toString()
    }
    
    console.log("支付宝支付回调数据:", paymentData)

    // 验证签名
    const isValidSign = verifyAlipaySign(paymentData)
    if (!isValidSign) {
      console.error("支付宝支付回调签名验证失败")
      return new NextResponse("failure", { status: 400 })
    }

    // 检查支付结果
    if (paymentData.trade_status === "TRADE_SUCCESS" || paymentData.trade_status === "TRADE_FINISHED") {
      const outTradeNo = paymentData.out_trade_no
      const tradeNo = paymentData.trade_no
      const totalAmount = parseFloat(paymentData.total_amount)

      // 查找支付记录
      const payment = await prisma.payment.findFirst({
        where: {
          transactionId: outTradeNo,
          status: "PENDING"
        },
        include: {
          article: true,
          user: true
        }
      })

      if (payment) {
        // 验证金额
        if (payment.amount !== totalAmount) {
          console.error("支付金额不匹配:", payment.amount, totalAmount)
          return new NextResponse("failure", { status: 400 })
        }

        // 更新支付状态
        await prisma.payment.update({
          where: { id: payment.id },
          data: {
            status: "COMPLETED",
            transactionId: tradeNo,
            updatedAt: new Date()
          }
        })

        console.log(`支付成功: 用户${payment.user.name}购买文章${payment.article.title}`)

        // 返回成功响应
        return new NextResponse("success", { status: 200 })
      } else {
        console.error("未找到支付记录:", outTradeNo)
        return new NextResponse("failure", { status: 400 })
      }
    } else {
      console.error("支付宝支付失败:", paymentData.trade_status)
      return new NextResponse("failure", { status: 400 })
    }

  } catch (error) {
    console.error("支付宝支付回调处理错误:", error)
    return new NextResponse("failure", { status: 500 })
  }
}

// 验证支付宝签名
function verifyAlipaySign(data: any): boolean {
  const alipayPublicKey = process.env.ALIPAY_PUBLIC_KEY || "your_public_key"
  
  // 1. 参数名ASCII码从小到大排序
  const sortedKeys = Object.keys(data).filter(key => key !== "sign" && key !== "sign_type").sort()
  
  // 2. 拼接参数
  let stringA = ""
  sortedKeys.forEach(key => {
    if (data[key] && data[key] !== "") {
      stringA += `${key}=${data[key]}&`
    }
  })
  
  // 3. 移除最后的&
  stringA = stringA.slice(0, -1)
  
  // 4. RSA2验签
  const crypto = require("crypto")
  const verify = crypto.createVerify("RSA-SHA256")
  verify.update(stringA)
  
  try {
    return verify.verify(alipayPublicKey, data.sign, "base64")
  } catch (error) {
    console.error("支付宝签名验证错误:", error)
    return false
  }
}





