import { NextRequest, NextResponse } from "next/server"
import { auth } from "@/lib/auth"
import prisma from "@/lib/prisma"
import { applyRateLimit } from "@/lib/rate-limit"
import { sanitizeObject } from "@/lib/validation"

// 支付宝支付统一下单API
export async function POST(request: NextRequest) {
  try {
    // 应用速率限制
    const rateLimitResponse = applyRateLimit(request, { windowMs: 15 * 60 * 1000, maxRequests: 5 })
    if (rateLimitResponse) {
      return rateLimitResponse
    }

    // 验证用户登录
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const body = await request.json()
    const { articleId, amount } = sanitizeObject(body)

    // 验证输入
    if (!articleId || !amount) {
      return NextResponse.json({ error: "缺少必要参数" }, { status: 400 })
    }

    if (amount <= 0 || amount > 10000) {
      return NextResponse.json({ error: "支付金额无效" }, { status: 400 })
    }

    // 验证文章是否存在
    const article = await prisma.article.findUnique({
      where: { id: articleId }
    })

    if (!article) {
      return NextResponse.json({ error: "文章不存在" }, { status: 404 })
    }

    if (!article.isPaid) {
      return NextResponse.json({ error: "该文章不是付费文章" }, { status: 400 })
    }

    if (article.price !== amount) {
      return NextResponse.json({ error: "支付金额不匹配" }, { status: 400 })
    }

    // 检查是否已经支付过
    const existingPayment = await prisma.payment.findFirst({
      where: {
        articleId,
        userId: session.user.id,
        status: "COMPLETED"
      }
    })

    if (existingPayment) {
      return NextResponse.json({ error: "您已经购买过该文章" }, { status: 400 })
    }

    // 生成订单号
    const outTradeNo = `ALI${Date.now()}${Math.random().toString(36).substr(2, 6)}`

    // 创建支付记录
    const payment = await prisma.payment.create({
      data: {
        articleId,
        userId: session.user.id,
        amount,
        method: "ALIPAY",
        status: "PENDING",
        transactionId: outTradeNo
      }
    })

    // 支付宝支付参数
    const alipayParams = {
      app_id: process.env.ALIPAY_APP_ID || "your_alipay_app_id",
      method: "alipay.trade.precreate",
      charset: "utf-8",
      sign_type: "RSA2",
      timestamp: new Date().toISOString().replace(/\.\d{3}Z$/, "Z"),
      version: "1.0",
      notify_url: `${process.env.NEXTAUTH_URL}/api/payment/alipay/notify`,
      biz_content: JSON.stringify({
        out_trade_no: outTradeNo,
        total_amount: amount.toString(),
        subject: `购买文章: ${article.title}`,
        product_code: "FACE_TO_FACE_PAYMENT"
      })
    }

    // 生成签名
    const sign = generateAlipaySign(alipayParams, process.env.ALIPAY_PRIVATE_KEY || "your_private_key")
    alipayParams.sign = sign

    // 调用支付宝API
    const alipayResponse = await callAlipayAPI(alipayParams)

    if (alipayResponse.alipay_trade_precreate_response && alipayResponse.alipay_trade_precreate_response.code === "10000") {
      return NextResponse.json({
        success: true,
        payment: {
          id: payment.id,
          outTradeNo,
          qrCodeUrl: alipayResponse.alipay_trade_precreate_response.qr_code,
          amount: payment.amount,
          method: payment.method,
          status: payment.status
        }
      })
    } else {
      return NextResponse.json({
        error: "支付宝下单失败",
        details: alipayResponse.alipay_trade_precreate_response?.sub_msg || "未知错误"
      }, { status: 500 })
    }

  } catch (error) {
    console.error("支付宝下单错误:", error)
    return NextResponse.json({ error: "支付下单失败" }, { status: 500 })
  }
}

// 生成支付宝签名
function generateAlipaySign(params: any, privateKey: string): string {
  // 1. 参数名ASCII码从小到大排序
  const sortedKeys = Object.keys(params).sort()
  
  // 2. 拼接参数
  let stringA = ""
  sortedKeys.forEach(key => {
    if (params[key] && params[key] !== "") {
      stringA += `${key}=${params[key]}&`
    }
  })
  
  // 3. 移除最后的&
  stringA = stringA.slice(0, -1)
  
  // 4. RSA2签名
  const crypto = require("crypto")
  const sign = crypto.createSign("RSA-SHA256")
  sign.update(stringA)
  return sign.sign(privateKey, "base64")
}

// 调用支付宝API
async function callAlipayAPI(params: any): Promise<any> {
  const formData = new URLSearchParams()
  Object.keys(params).forEach(key => {
    formData.append(key, params[key])
  })
  
  try {
    const response = await fetch("https://openapi.alipay.com/gateway.do", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: formData.toString()
    })
    
    const responseText = await response.text()
    return JSON.parse(responseText)
  } catch (error) {
    console.error("支付宝API调用失败:", error)
    throw error
  }
}





