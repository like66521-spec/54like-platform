import { NextRequest, NextResponse } from "next/server"
import { auth } from "@/lib/auth"
import prisma from "@/lib/prisma"
import { applyRateLimit } from "@/lib/rate-limit"
import { sanitizeObject } from "@/lib/validation"

// 微信支付统一下单API
export async function POST(request: NextRequest) {
  try {
    // 应用速率限制
    const rateLimitResponse = applyRateLimit(request, { windowMs: 15 * 60 * 1000, maxRequests: 5 })
    if (rateLimitResponse) {
      return rateLimitResponse
    }

    // 验证用户登录
    const session = await auth()
    if (!session) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 })
    }

    const body = await request.json()
    const { articleId, amount } = sanitizeObject(body)

    // 验证输入
    if (!articleId || !amount) {
      return NextResponse.json({ error: "缺少必要参数" }, { status: 400 })
    }

    if (amount <= 0 || amount > 10000) {
      return NextResponse.json({ error: "支付金额无效" }, { status: 400 })
    }

    // 验证文章是否存在
    const article = await prisma.article.findUnique({
      where: { id: articleId }
    })

    if (!article) {
      return NextResponse.json({ error: "文章不存在" }, { status: 404 })
    }

    if (!article.isPaid) {
      return NextResponse.json({ error: "该文章不是付费文章" }, { status: 400 })
    }

    if (article.price !== amount) {
      return NextResponse.json({ error: "支付金额不匹配" }, { status: 400 })
    }

    // 检查是否已经支付过
    const existingPayment = await prisma.payment.findFirst({
      where: {
        articleId,
        userId: session.user.id,
        status: "COMPLETED"
      }
    })

    if (existingPayment) {
      return NextResponse.json({ error: "您已经购买过该文章" }, { status: 400 })
    }

    // 生成订单号
    const outTradeNo = `WX${Date.now()}${Math.random().toString(36).substr(2, 6)}`

    // 创建支付记录
    const payment = await prisma.payment.create({
      data: {
        articleId,
        userId: session.user.id,
        amount,
        method: "WECHAT",
        status: "PENDING",
        transactionId: outTradeNo
      }
    })

    // 微信支付统一下单参数
    const wechatPayParams = {
      appid: process.env.WECHAT_APP_ID || "your_wechat_app_id",
      mch_id: process.env.WECHAT_MCH_ID || "your_merchant_id",
      nonce_str: generateNonceStr(),
      body: `购买文章: ${article.title}`,
      out_trade_no: outTradeNo,
      total_fee: Math.round(amount * 100), // 转换为分
      spbill_create_ip: getClientIP(request),
      notify_url: `${process.env.NEXTAUTH_URL}/api/payment/wechat/notify`,
      trade_type: "NATIVE", // 扫码支付
      product_id: articleId
    }

    // 生成签名
    const sign = generateWechatSign(wechatPayParams, process.env.WECHAT_API_KEY || "your_api_key")
    wechatPayParams.sign = sign

    // 调用微信支付API
    const wechatResponse = await callWechatPayAPI(wechatPayParams)

    if (wechatResponse.return_code === "SUCCESS" && wechatResponse.result_code === "SUCCESS") {
      return NextResponse.json({
        success: true,
        payment: {
          id: payment.id,
          outTradeNo,
          qrCodeUrl: wechatResponse.code_url,
          amount: payment.amount,
          method: payment.method,
          status: payment.status
        }
      })
    } else {
      return NextResponse.json({
        error: "微信支付下单失败",
        details: wechatResponse.return_msg || wechatResponse.err_code_des
      }, { status: 500 })
    }

  } catch (error) {
    console.error("微信支付下单错误:", error)
    return NextResponse.json({ error: "支付下单失败" }, { status: 500 })
  }
}

// 生成随机字符串
function generateNonceStr(): string {
  return Math.random().toString(36).substr(2, 32)
}

// 获取客户端IP
function getClientIP(request: NextRequest): string {
  const forwarded = request.headers.get("x-forwarded-for")
  const realIP = request.headers.get("x-real-ip")
  
  if (forwarded) {
    return forwarded.split(",")[0].trim()
  }
  
  if (realIP) {
    return realIP
  }
  
  return "127.0.0.1"
}

// 生成微信支付签名
function generateWechatSign(params: any, apiKey: string): string {
  // 1. 参数名ASCII码从小到大排序
  const sortedKeys = Object.keys(params).sort()
  
  // 2. 拼接参数
  let stringA = ""
  sortedKeys.forEach(key => {
    if (params[key] && params[key] !== "") {
      stringA += `${key}=${params[key]}&`
    }
  })
  
  // 3. 拼接API密钥
  stringA += `key=${apiKey}`
  
  // 4. MD5加密并转大写
  const crypto = require("crypto")
  return crypto.createHash("md5").update(stringA).digest("hex").toUpperCase()
}

// 调用微信支付API
async function callWechatPayAPI(params: any): Promise<any> {
  const xml = buildXML(params)
  
  try {
    const response = await fetch("https://api.mch.weixin.qq.com/pay/unifiedorder", {
      method: "POST",
      headers: {
        "Content-Type": "application/xml"
      },
      body: xml
    })
    
    const responseText = await response.text()
    return parseXML(responseText)
  } catch (error) {
    console.error("微信支付API调用失败:", error)
    throw error
  }
}

// 构建XML
function buildXML(params: any): string {
  let xml = "<xml>"
  Object.keys(params).forEach(key => {
    xml += `<${key}><![CDATA[${params[key]}]]></${key}>`
  })
  xml += "</xml>"
  return xml
}

// 解析XML
function parseXML(xml: string): any {
  const result: any = {}
  const regex = /<(\w+)><!\[CDATA\[(.*?)\]\]><\/\1>/g
  let match
  
  while ((match = regex.exec(xml)) !== null) {
    result[match[1]] = match[2]
  }
  
  return result
}





