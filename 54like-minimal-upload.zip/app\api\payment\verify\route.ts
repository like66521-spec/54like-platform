import { type NextRequest, NextResponse } from "next/server"
import { applyRateLimit } from "@/lib/rate-limit"
import { sanitizeText, validateStringLength } from "@/lib/validation"

export async function POST(request: NextRequest) {
  try {
    // 应用严格速率限制
    const rateLimitResponse = applyRateLimit(request, { windowMs: 15 * 60 * 1000, maxRequests: 10 })
    if (rateLimitResponse) {
      return rateLimitResponse
    }

    const body = await request.json()
    const { paymentId } = body

    // 验证和清理输入
    if (!paymentId || !validateStringLength(paymentId, 1, 100)) {
      return NextResponse.json({ error: "Invalid payment ID" }, { status: 400 })
    }

    const sanitizedPaymentId = sanitizeText(paymentId)

    // 查询支付记录
    const payment = await prisma.payment.findUnique({
      where: { id: sanitizedPaymentId },
      include: {
        article: true,
        user: true
      }
    })

    if (!payment) {
      return NextResponse.json({ error: "支付记录不存在" }, { status: 404 })
    }

    // 检查支付状态
    if (payment.status === "COMPLETED") {
      return NextResponse.json({
        success: true,
        status: "completed",
        message: "支付已完成",
        payment: {
          id: payment.id,
          amount: payment.amount,
          method: payment.method,
          status: payment.status,
          createdAt: payment.createdAt
        }
      })
    }

    // 模拟支付验证（实际应用中应该调用支付网关API）
    // 这里为了演示，随机决定是否支付成功
    const isSuccess = Math.random() > 0.3 // 70% 成功率

    if (isSuccess) {
      // 更新支付状态为已完成
      await prisma.payment.update({
        where: { id: sanitizedPaymentId },
        data: { 
          status: "COMPLETED",
          updatedAt: new Date()
        }
      })

      return NextResponse.json({
        success: true,
        status: "completed",
        message: "支付验证成功",
        payment: {
          id: payment.id,
          amount: payment.amount,
          method: payment.method,
          status: "COMPLETED",
          createdAt: payment.createdAt
        }
      })
    } else {
      return NextResponse.json({
        success: false,
        status: "pending",
        message: "支付尚未完成，请继续等待",
        payment: {
          id: payment.id,
          amount: payment.amount,
          method: payment.method,
          status: payment.status,
          createdAt: payment.createdAt
        }
      })
    }
  } catch (error) {
    console.error("[v0] Payment verification error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
