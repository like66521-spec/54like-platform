# 54LIKE - 优质内容分享平台 
 
这是一个基于Next.js的内容分享平台�?
 
## 技术栈 
- Next.js 15 
- React 19 
- TypeScript 
- Prisma 
- Tailwind CSS 
 
## 部署 
支持Vercel一键部署�?
